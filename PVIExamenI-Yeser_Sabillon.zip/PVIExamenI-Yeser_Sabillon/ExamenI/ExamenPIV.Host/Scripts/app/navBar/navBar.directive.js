﻿app.directive('proyectoNavBar', function() {
    return {
        templateUrl: '/Scripts/app/navBar/navBar.template.html'
    };
});