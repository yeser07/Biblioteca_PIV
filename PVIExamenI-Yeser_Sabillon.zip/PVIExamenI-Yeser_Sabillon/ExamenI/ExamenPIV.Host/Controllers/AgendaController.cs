﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ExamenPIV.Data;
using ExamenPIV.Data.Modelos;
using System.Web.Http.Description;

namespace ExamenPIV.Host.Controllers
{
    public class AgendaController : ApiController
    {
        ExamenIPivContext examenIPiVContext = new ExamenIPivContext("ExamenIPVI");

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                examenIPiVContext.Dispose();
            }

            base.Dispose(disposing);
        }
        // GET: api/Agenda
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Agenda/5

        [ResponseType(typeof(Agenda))]
        public IHttpActionResult Get(int id)
        {
            var agenda = examenIPiVContext.Agenda.Find(id);
            if (agenda == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(agenda);
            };
        }

        // POST: api/Agenda
        [ResponseType(typeof(Agenda))]
        public IHttpActionResult Post(Agenda nuevaAgenda)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            examenIPiVContext.Agenda.Add(nuevaAgenda);
            examenIPiVContext.SaveChanges();
            return Ok(nuevaAgenda);
        }


        [Route("api/Agenda/{idAgenda}/Entradas/{idEntrada}")]
        [HttpPost]
        [ResponseType(typeof(Agenda))]
        public IHttpActionResult AgregarEntrada(int idAgenda, int idEntrada)
        {
            var agenda = examenIPiVContext.Agenda.Find(idAgenda);
            var entrada = examenIPiVContext.Entrada.Find(idEntrada);
            if (agenda == null || entrada == null)
            {
                return NotFound();
            }
            agenda.agregarEntrada(entrada);
            examenIPiVContext.SaveChanges();
            return Ok();
        }

        // PUT: api/Agenda/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Agenda/5
        public void Delete(int id)
        {
        }
    }
}
