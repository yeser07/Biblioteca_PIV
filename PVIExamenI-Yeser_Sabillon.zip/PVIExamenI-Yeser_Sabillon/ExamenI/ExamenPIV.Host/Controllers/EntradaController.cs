﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ExamenPIV.Data;
using ExamenPIV.Data.Modelos;
using System.Web.Http.Description;

namespace ExamenPIV.Host.Controllers
{
    public class EntradaController : ApiController
    {
        ExamenIPivContext examenIPiVContext = new ExamenIPivContext("ExamenIPVI");

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                examenIPiVContext.Dispose();
            }

            base.Dispose(disposing);
        }





        // GET: api/Entrada
        public IEnumerable<Entrada> Get()
        {
            return examenIPiVContext.Entrada;
        }

        // GET: api/Entrada/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Entrada            
        [ResponseType(typeof(Entrada))]
        public IHttpActionResult nuevaEntrada(Entrada nuevaEntrada)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            examenIPiVContext.Entrada.Add(nuevaEntrada);
            examenIPiVContext.SaveChanges();
            return Ok(nuevaEntrada);
        }

        // PUT: api/Entrada/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Entrada/5
        public void Delete(int id)
        {
        }
    }
}
