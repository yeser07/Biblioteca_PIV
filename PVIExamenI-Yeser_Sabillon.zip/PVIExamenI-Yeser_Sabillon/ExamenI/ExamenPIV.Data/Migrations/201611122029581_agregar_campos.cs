namespace ExamenPIV.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class agregar_campos : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Agenda",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Nombre = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Entradas",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Nombre = c.String(),
                        Telefono = c.String(),
                        Email = c.String(),
                        Agenda_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Agenda", t => t.Agenda_Id)
                .Index(t => t.Agenda_Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Entradas", "Agenda_Id", "dbo.Agenda");
            DropIndex("dbo.Entradas", new[] { "Agenda_Id" });
            DropTable("dbo.Entradas");
            DropTable("dbo.Agenda");
        }
    }
}
