﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenPIV.Data.Modelos
{
    public class Agenda
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public IList<Entrada> Entradas { get; set; }

        public void agregarEntrada(Entrada nuevaEntrada)
        {
            Entradas.Add(nuevaEntrada);
        }
    }
}
